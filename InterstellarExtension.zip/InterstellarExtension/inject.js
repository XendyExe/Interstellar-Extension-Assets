ingame = location.hash != "#vanilla"

if (ingame) {
    let splashScreen = document.createElement("div");
    splashScreen.id = "StellarSplashScreen";
    splashScreen.style.background = "#000000";
    splashScreen.style.zIndex = "10000000";
    splashScreen.style.width = "100%";
    splashScreen.style.height = "100%";
    splashScreen.style.position = "absolute";
    splashScreen.style.textAlign = "center";
    splashScreen.innerHTML = `
        <div style="display: flex; justify-content: center; align-items: center; width:100%; height:100%; flex-direction: column;zIndex: 1000000000">
            <h1 style="color:white; font-size: 200px; margin: 0; padding: 0;">Interstellar</h1>
            <p style="color:white;" id="vanillasendertext">Click 5 times to be sent to vanilla (Skips loading)</p>
            <div id="loadingbar" style="width: 75%; height: 64px; background-color: gray; opacity:0; display: flex; align-items: center;">
            </div>
            <div id="loadingLoggerDisplay" style="height:20%; color:white; overflow:hidden; padding: 0;display: flex;flex-direction: column; margin-top: 5%;">
                <span>Loading website...</span>
                <div style="width:100%; position: fixed; background: linear-gradient(to bottom, rgba(0, 0, 0, 0), rgba(0, 0, 0, 1)); height:inherit;z-index:10000000000"></div>
            </div>
        </div>
    </div>`
    let launched = false;
    (function() {
        new MutationObserver((_, observer) => {
            const scriptTag = document.querySelectorAll('script');
            let scriptTagsArray = Array.from(scriptTag);
            scriptTagsArray.forEach(function(tag) {
                if (tag.innerText.includes("test.drednot.io")) {
                    if (document.body && !launched) {
                        document.body.appendChild(splashScreen);
                        launched = true;
                    }
                    tag.id = "OLD_SCRIPT_TAG";
                    tag.type = "text/plain";
                    window.onload = () => {
                        let script = document.createElement("script");
                        script.src = chrome.runtime.getURL("launch.js");
                        tag.parentElement.appendChild(script);
                    }
                    observer.disconnect();
                }
            });
        }).observe(document.documentElement, { childList: true, subtree: true, characterData: true });
    })();
}