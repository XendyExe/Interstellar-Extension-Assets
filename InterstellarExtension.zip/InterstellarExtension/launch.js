window.istest = false;
window.starttime = Date.now();
window.INTERSTELLAR_CACHE = {}
function formatBytes(bytes) {
    if (bytes === 0) return '0 bytes';
    const k = 1024;
    const sizes = ['bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
} 
function msToMmSs(ms) {
    let seconds = Math.floor(ms / 1000);
    let minutes = Math.floor(seconds / 60);
    seconds = seconds % 60;
    let formattedMinutes = minutes < 10 ? `0${minutes}` : `${minutes}`;
    let formattedSeconds = seconds < 10 ? `0${seconds}` : `${seconds}`;
    return `${formattedMinutes}:${formattedSeconds}`;
}

window.iaurl = (path) => {
    return INTERSTELLAR_CACHE[path];
}
window.SENDING_TO_VANILLA = false;

window.stellarAsset = async (path) => {
    const transaction = interstellarDatabase.transaction(["assets"], "readwrite");
    const store = transaction.objectStore("assets");

    return new Promise((resolve, reject) => {
        const request = store.get(path);
        
        request.onsuccess = (event) => {
            const blob = request.result.blob;
            resolve(blob);
        };

        request.onerror = () => {
            reject(new Error('Failed to retrieve asset from database'));
        };
    });
}
async function requestPersistentStorage() {
    if (navigator.storage && navigator.storage.persist) {
        const isPersisted = await navigator.storage.persisted();
        if (!isPersisted) {
            const result = await navigator.storage.persist();
            return result;
        }
        return isPersisted;
    } else {
        console.warn("Persistent storage API not supported by the browser.");
        return false;
    }
}

{
    const splashScreen = document.querySelector("#StellarSplashScreen");
    const loggerElm = document.querySelector("#loadingLoggerDisplay");
    const loadingBar = document.querySelector("#loadingbar");
    let startTime = performance.now();
    let logger = (arg) => {
        let elm = document.createElement("span");
        elm.innerHTML = arg;
        loggerElm.prepend(elm);
        console.log("[Interstellar Launcher]", arg)
    }
    let skipcount = 0;
    let vanillasendertext = document.querySelector("#vanillasendertext")
    window.skipLoading = (e) => {
        skipcount += 1;
        if (5-skipcount > 0) {
            vanillasendertext.innerHTML = `Click ${5-skipcount} more times to be sent to vanilla!`
            logger(`Click ${5-skipcount} more times to be sent to vanilla!`)
        }
        else {
            vanillasendertext.innerHTML = `Sending you to vanilla!`
            logger(`Sending to vanila!!`)
            window.SENDING_TO_VANILLA = true;
            location.hash = "vanilla";
            location.reload();
        }
    }
    document.addEventListener("click", skipLoading);
    window.interstellarDatabase = null;
    const LaunchInterstellarDatabase = () => {
        logger("Launching database");
        const request = indexedDB.open("interstellarDatabase", 2);
        request.onupgradeneeded = (event) => {
            logger("Updating Database...");
            interstellarDatabase = event.target.result;

            if (!interstellarDatabase.objectStoreNames.contains("assets")) {
                interstellarDatabase.createObjectStore("assets", {});
                logger("Created Assets Object Store!");
            }
        };

        request.onsuccess = (event) => {
            interstellarDatabase = event.target.result;
            logger("Launched interstellar database");
            InitalizeInterstellar();
        };

        request.onerror = (event) => {
            alert("Failed to load interstellar database! Check console.")
            console.error("Failed to load interstellar database error: " + event.target.errorCode);
        };
    }

    const checkForUpdates = (files, filepaths) => {
        return new Promise((resolve, reject) => {
            const transaction = interstellarDatabase.transaction(["assets"], "readwrite");
            const store = transaction.objectStore("assets");
            let missing = [];
            let remove = [];
            let change = [];
            let bytes_download = 0;

            let waiting = 1;
            for (let file of files) {
                const path = file[0];
                const sha = file[1];
                const url = file[2];
                const length = file[3];
                if (path.endsWith(".zip") || path.endsWith("md")) continue;
                let getRequest = store.get(path);
                getRequest.onsuccess = (event) => {
                    const storedFile = event.target.result;
                    if (storedFile === undefined) {
                        missing.push([path, length, sha]);
                        bytes_download += length;
                    } else {
                        if (sha != storedFile.sha) {
                            change.push([path, length, sha]);
                            bytes_download += length;
                        }
                        else {
                            INTERSTELLAR_CACHE[path] = URL.createObjectURL(storedFile.blob);
                        }
                    }
                    waiting -= 1;
                }
                getRequest.onerror = (event) => {
                    console.error("Error fetching file: " + event.target.errorCode);
                    waiting -= 1;
                };
                waiting += 1;
            }
            let getRequest = store.getAllKeys();
            getRequest.onsuccess = (event) => {
                let paths = event.target.result;
                for (let path of paths) {
                    if (!filepaths.includes(path)) remove.push(path);
                }
                waiting --;
            }
            getRequest.onerror = (event) => {
                console.error("Error findin gdeleted files: " + event.target.errorCode);
                waiting -= 1;
            };
            const loop = () => {
                if (waiting == 0) {
                    resolve({
                        "missing": missing,
                        "remove": remove,
                        "change": change,
                        "bytes": bytes_download,
                        "needUpdate": !(remove.length == 0 && bytes_download == 0)
                    })
                }
                setTimeout(loop, 10);
            }
            loop();
        })
    }
    const updateGame = async (files, paths) => {
        logger("Requesting persistant storage...");
        await requestPersistentStorage();
        logger("Checking for updates...");
        let updateData = await checkForUpdates(files, paths);
        if (updateData.needUpdate) {
            loadingBar.style.opacity = 1;
            const loading = document.createElement("div");
            loading.style.width = "0%";
            loading.style.backgroundColor = "white";
            loading.style.height = "95%";
            loading.style.color="black";
            loading.style.display = "flex";
            loading.style.alignContent = "center";
            loading.style.flexWrap = "wrap";
            loading.style.paddingLeft = "16px";
            loading.style.fontSize = "24px";
            loadingBar.appendChild(loading);
            let totalChanges = updateData.missing.length + updateData.change.length;
            logger(`${updateData.missing.length} additions, ${updateData.change.length} changes, ${updateData.remove.length} deletions`);
            logger(`Found ${formatBytes(updateData.bytes)} update.`);
            let bytesDownloaded = 0;
            let files = 0;
            let fetched_files = {}
            const need_to_fetch = [...updateData.missing, ...updateData.change]
            if (need_to_fetch.length > 0) {
                const updatespan = document.createElement("span");
                const nerdStuff = document.createElement("span");
                loggerElm.prepend(nerdStuff);
                loggerElm.prepend(updatespan);
                let fetches_all = [];
                const MAX_FETCH_AMOUNT = 32;
                const MAX_FETCH_BYTES = 3000000;
                let current_fetch_bytes = 0;
                let sync_files = 0;
                for (let missing of need_to_fetch) {
                    if (fetches_all.length >= MAX_FETCH_AMOUNT || current_fetch_bytes >= MAX_FETCH_BYTES) {
                        let bps = bytesDownloaded/(performance.now()/1000);
                        updatespan.innerHTML = `Downloading ${sync_files} files concurrently (${formatBytes(current_fetch_bytes)}) ${files}/${totalChanges} at ${formatBytes(bps)}PS`
                        nerdStuff.innerHTML = `${current_fetch_bytes}`
                        current_fetch_bytes = 0;
                        sync_files = 0;
                        await Promise.all(fetches_all);
                        fetches_all = [];
                    }
                    fetches_all.push((async (file) => {
                        let s = `${formatBytes(bytesDownloaded)}/${formatBytes(updateData.bytes)}`.replaceAll(" ", "").replaceAll("B", "b");
                        loading.innerHTML = `${s}`;
                        files += 1;
                        let blob = await fetch("https://interstellar.myvnc.com/stellarassets/" + file[0], {cache: "no-store"}).then(res=>res.blob()).catch(e=>{
                            logger("Failed to fetch! Check console.")
                            throw e;
                        })
                        fetched_files[file[0]] = {
                            blob: blob,
                            sha: file[2]
                        };
                        INTERSTELLAR_CACHE[file[0]] = URL.createObjectURL(blob);
                        bytesDownloaded += file[1];
                        loading.style.width = `${(bytesDownloaded/updateData.bytes)*100}%`;
                    })(missing));
                    sync_files += 1;
                    current_fetch_bytes += missing[1];
                }
                await Promise.all(fetches_all);
                logger(`Saving all files!`)
                loading.innerHTML = ``;
                const transaction = interstellarDatabase.transaction(["assets"], "readwrite");
                const store = transaction.objectStore("assets");
                let dkeys = Object.keys(fetched_files);
                const savespan = document.createElement("span");
                loggerElm.prepend(savespan);
                let waiting = 0;
                for (let path of dkeys) {
                    waiting += 1;
                    savespan.innerHTML = `Saving ${path}`
                    const request = store.put(fetched_files[path], path);
                    request.onerror = (e) => {
                        logger("Failed to save " + path + ". Check console.");
                        throw e;
                    }
                    request.onsuccess = (e) => {
                        waiting -= 1;
                    }
                }
                await new Promise((resolve, reject) => { const loop = () => { if (waiting == 0) resolve(); setTimeout(loop, 10); }; loop();})
            }
            loading.style.width = "100%";
            if (updateData.remove.length != 0) {
                logger(`Deleting ${updateData.remove.length} files...`);
                const transaction = interstellarDatabase.transaction(["assets"], "readwrite");
                const store = transaction.objectStore("assets");
                let waiting = 0;
                for (let path of updateData.remove) {
                    waiting += 1;
                    const request = store.delete(path);
                    request.onerror = (e) => {
                        logger("Failed to save " + path + ". Check console.");
                        throw e;
                    }
                    request.onsuccess = (e) => {
                        waiting -= 1;
                    }
                }
                await new Promise((resolve, reject) => { const loop = () => { if (waiting == 0) resolve(); setTimeout(loop, 10); }; loop();})
            }
        }
        logger(`Launching...`);
        let e = document.createElement("script");
        e.innerHTML = await (await stellarAsset("scripts/superloader.js")).text();
        document.body.appendChild(e);
        document.removeEventListener("click", skipLoading);
        vanillasendertext.innerHTML = "";
    }

    const InitalizeInterstellar = async () => {
        const tree = await fetch("https://api.github.com/repos/XendyExe/Interstellar-Extension-Assets/git/trees/master?recursive=1").then(res => res.json());
        let files = [];
        let paths = [];
        for (data of tree.tree) {
            if (data.type != "blob") continue;
            paths.push(data.path);
            files.push([data.path, data.sha, data.url, data.size]);
        }
        updateGame(files, paths);
    }
    LaunchInterstellarDatabase();
}